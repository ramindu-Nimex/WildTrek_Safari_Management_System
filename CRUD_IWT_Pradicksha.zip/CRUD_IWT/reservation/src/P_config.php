<?php
// Create connection
$conn = new mysqli('localhost', 'root', '', 'hotel_reservation');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>